 /* Christiana Wu
 * 20767703
 * Project 3 
 * This is just creates the binary tree for th game 20 questions 
 * this in put for this file is yes or no for each of the questions in the tree if your right no then it 
 * it will ask for your object then a question that distingues the two objects and it will also as if yur object is yes 
 * or no for this question.
 * September 18, 2019
 */
import java.io.PrintStream;
import java.util.Scanner;

public class QuestionTree {
	private PrintStream out;
	private Scanner input;
	private QuestionNode node;
	private int totalGames = 0;
	private int gamesWon = 0;
	
	//constructor
	public QuestionTree(Scanner input,PrintStream output) {
		if(input == null || output == null) {
			throw new IllegalArgumentException();
		}
		this.input = input;
		this.out = output;
		this.node= new QuestionNode ("Jedi");
	}
	
	public void play() {
		//helper method 
		totalGames++;
		this.node = play(this.node);
	}
	
	private QuestionNode play (QuestionNode child) {
		//base case
		if (child.left == null && child.right == null) {
			this.out.print("Would your object happen to be " + child.data + "?");
			if(UserInterface.nextAnswer(input)) { //if computer guess is not right
				this.out.println("I win!"); //if computer was right
				gamesWon++;
			}else{
				this.out.print("I lose. What is your object?");  //get the new answer and create it into a new node
				String sUserInput = input.nextLine();
				this.out.print("Type a yes/no quesiton to distinguish you item from " + child.data + ":");  //Answer to distinguash the new answer
				String ssUserInput = input.nextLine();
				this.out.print("And what is the answer for your object?"); //Answer for player's object to the questions
				if (!UserInterface.nextAnswer(input)) {
					return new QuestionNode (ssUserInput,new QuestionNode(child.data),new QuestionNode(sUserInput));
				}else {	
					return new QuestionNode (ssUserInput,new QuestionNode(sUserInput),new QuestionNode(child.data));
				}
			}
		}else {			
			this.out.print(child.data); //guessing the object
			if(UserInterface.nextAnswer(input)) {
				child.left = play(child.left);
			}else {
				child.right = play (child.right);
			}
		}
		return child;
	}
	
//	public void save(PrintStream output) {
//		if (output == null) {
//			throw new IllegalArgumentException();
//		}else {
//			save(this.node,output);
//		}
//	}
//	
//	private void save(QuestionNode node,PrintStream output) {
//		if(node == null) {
//			return;
//		}	
//		if(node.left ==null && node.right == null) { //print the right line to the txt file
//			output.println("A:"+node.data);
//		}else {
//			output.println("Q:"+node.data);
//		}
//		save(node.left,output);
//	 	save(node.right,output);
//	}
	
	public void load (Scanner input) {
		if (input == null) {
			throw new IllegalArgumentException();
		}else {
			QuestionNode pointer = this.node;
			this.node = load(pointer,input);
		}
	}
	
	private QuestionNode load (QuestionNode node, Scanner input) {
		String newNode = input.nextLine();
		node = new QuestionNode (newNode.substring(2));
		if (newNode.startsWith("Q")) { //If it is a Q then add a node to it 
			node.left = load(node.left,input);
			node.right = load(node.right,input);
		}
		return node;
	}
	
	public int totalGames (){
		return this.totalGames;
	}
	
	public int gamesWon () {
		return this.gamesWon;
	}
	
}
